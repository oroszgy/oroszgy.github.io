#include <iostream>
#include <ctime>
#include <ratio>
#include <chrono>
#include <math.h>       /* sqrt */
#include <stdlib.h>     /* atoi */

using namespace std;

unsigned int FermatFactor(unsigned int oddNumber)
{
    unsigned int a = sqrt(oddNumber)+1;
    unsigned int b2 = a*a - oddNumber;
    // std::cout << "B2: " << b2 << "a: " << a << std::endl;

    unsigned int tmp = sqrt(b2);
    while (tmp*tmp != b2)
    {
        a = a + 1;
        b2 = a*a - oddNumber;
        // std::cout << "B2: " << b2 << "a: " << a << std::endl;
        tmp = sqrt(b2);
    }

    // std::cout << "FERMAT: " << a + tmp << ", " << a - tmp <<std::endl;
    return a + tmp;
}


int main(int argc, char *argv[]) {
    using namespace std::chrono;

    unsigned int my_num;

    if (argc < 2) {
        cout << "input number: ";
        cin >> my_num;
    } else {
        my_num = atoi(argv[1]);
    }

    cout << "your number is: " << my_num << endl;

    steady_clock::time_point t1 = steady_clock::now();

    cout << "FERMAT: " << FermatFactor(my_num) << endl;

    steady_clock::time_point t2 = steady_clock::now();

    duration<double> time_span = duration_cast<duration<double>>(t2 - t1);

    std::cout << "It took me " << time_span.count() << " seconds.";
    std::cout << std::endl;

    return 0;
}
