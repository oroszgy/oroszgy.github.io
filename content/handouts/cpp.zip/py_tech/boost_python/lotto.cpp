// g++ greet_binding.cpp -I/usr/include/python3.4 -I/usr/local/include
// -I/usr/include/python3.4m -lboost_python3 -lpython3.4m -fPIC -o greet.so -shared


#include <iostream>
#include <vector>
#include <random>
#include <chrono>
#include <boost/python.hpp>
#include <boost/python/def.hpp>
#include <boost/python/module.hpp>

using namespace std;
namespace bp = boost::python;


//the following are UBUNTU/LINUX ONLY terminal color codes.
#define RESET   "\033[0m"
#define BLACK   "\033[30m"      /* Black */
#define RED     "\033[31m"      /* Red */
#define GREEN   "\033[32m"      /* Green */
#define YELLOW  "\033[33m"      /* Yellow */
#define BLUE    "\033[34m"      /* Blue */
#define MAGENTA "\033[35m"      /* Magenta */
#define CYAN    "\033[36m"      /* Cyan */
#define WHITE   "\033[37m"      /* White */
#define BOLDBLACK   "\033[1m\033[30m"      /* Bold Black */
#define BOLDRED     "\033[1m\033[31m"      /* Bold Red */
#define BOLDGREEN   "\033[1m\033[32m"      /* Bold Green */
#define BOLDYELLOW  "\033[1m\033[33m"      /* Bold Yellow */
#define BOLDBLUE    "\033[1m\033[34m"      /* Bold Blue */
#define BOLDMAGENTA "\033[1m\033[35m"      /* Bold Magenta */
#define BOLDCYAN    "\033[1m\033[36m"      /* Bold Cyan */
#define BOLDWHITE   "\033[1m\033[37m"      /* Bold White */

class Lotto
{
    std::vector< std::vector<int> > my_plays;
    int numbers = 0;
public:
    Lotto(const int N)
    {
        typedef std::chrono::high_resolution_clock Clock;
        typedef std::chrono::duration<double> sec;
        Clock::time_point t0 = Clock::now();

        // Random seed
        random_device rd;

        // Initialize Mersenne Twister pseudo-random number generator
        mt19937 gen(rd());

        // Generate pseudo-random numbers
        uniform_int_distribution<> dis(1, 90);

        // declare 2D vector
        std::vector< std::vector<int> > plays;
        for (int i = 0; i < N; ++i) {
            vector<int> row;
            for (int j = 0; j < 5; ++j) {
                row.push_back(dis(gen));
            }
            row.push_back(0);
            plays.push_back(row);
        }
        Clock::time_point t1 = Clock::now();
        std::cout << RED << N/sec(t1-t0).count()
                  << " random numbers per second."  << RESET << endl;
        this->my_plays = plays;
    }

    bp::list nth_play(const int n)
    {
        bp::list ret;
        for (int s : my_plays.at(n)) ret.append(s);
        return ret;
    }

    void evaluate() {
        int match_1 = 0;
        int match_2 = 0;
        int match_3 = 0;
        int match_4 = 0;
        int match_5 = 0;
        for (unsigned i = 0; i < my_plays.size(); ++i) {
            switch(my_plays[i][5])
            {
            case 1 :
              match_1++;
              break;
            case 2 :
              match_2++;
              break;
            case 3 :
              match_3++;
              break;
            case 4 :
              match_4++;
              break;
            case 5 :
              match_5++;
              break;
            default:
              break;
            }
        }
        std::cout << "5 match: " << match_5 << endl;
        std::cout << "4 match: " << match_4 << endl;
        std::cout << "3 match: " << match_3 << endl;
        std::cout << "2 match: " << match_2 << endl;
        std::cout << "1 match: " << match_1 << endl;
    }

    void pull_number(int n) {
        for (unsigned i = 0; i < my_plays.size(); ++i) {
            for (int j = 0; j < 5; ++j) {
                if (my_plays[i][j] == n) {
                    ++my_plays[i][5];
                }
            }
        }
        numbers++;
        cout << numbers << ". pull is " << n << ". Pulls left: " << 5 - numbers << endl;
        if (numbers == 5) {evaluate();}
    }

};

void my_random(int n)
{
    // Random seed
    random_device rd;

    // Initialize Mersenne Twister pseudo-random number generator
    mt19937 gen(rd());

    // Generate pseudo-random numbers
    // uniformly distributed in range (1, 100)
    uniform_int_distribution<> dis(1, 90);

    // Generate ten pseudo-random numbers
    for (int i = 0; i < n; i++)
    {
        int randomX = dis(gen);
        cout << "\nRandom X = " << randomX;
    }
}


BOOST_PYTHON_MODULE(lotto_c)
{
    bp::def("my_random", my_random);
    // bp::def("double_it", double_it);
    // bp::def("zeroes", zeroes);
    // bp::def("gen_random", gen_random);

    bp::class_<Lotto>("Lotto", bp::init<const int>())
    .def("nth_play", &Lotto::nth_play)
    .def("pull_number", &Lotto::pull_number)
    .def("evaluate", &Lotto::evaluate)
    ;
}
