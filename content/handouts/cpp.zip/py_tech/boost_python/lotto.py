#!/usr/bin/python3

import lotto_c

my_lotto = lotto_c.Lotto(200000)

my_lotto.pull_number(1)
my_lotto.pull_number(43)
my_lotto.pull_number(89)
my_lotto.pull_number(77)
my_lotto.pull_number(15)

my_lotto.evaluate()
