"""
single threaded version
"""

import math
import time

def timeit(method):
	"""Timer decorator to keep an eye on CPU hungry processes"""
	def timed(*args, **kw):
		ts = time.time()
		result = method(*args, **kw)
		te = time.time()

		print('\x1b[31m%r -> %2.2f sec\x1b[0m' % (method.__name__, te-ts))
		return result

	return timed

def isprime(n):
	"""Returns True if n is prime and False otherwise"""
	if not isinstance(n, int):
		raise TypeError("argument passed to is_prime is no 'int'")
	if n < 2:
		return False
	if n == 2:
		return True
	max = int(math.ceil(math.sqrt(n)))
	i = 2
	while i <= max:
		if n % i == 0:
			return False
		i += 1
	return True


def sum_primes(n):
	"""Calculates sum of all primes below given integer n"""
	return sum([x for x in range(2, n) if isprime(x)])

@timeit
def calculate():
	for i in xrange(100000, 1000000, 100000):
		print(i)
		print(sum_primes(i))


if __name__ == '__main__':
	calculate()
