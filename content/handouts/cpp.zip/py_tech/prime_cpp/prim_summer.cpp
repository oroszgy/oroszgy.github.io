#include <iostream>
#include <chrono>

#include "pnum.h"

#include <boost/python.hpp>
#include <boost/python/def.hpp>
#include <boost/python/module.hpp>

using namespace std;
namespace bp = boost::python;

void sum_primes(unsigned int n)
{
    using namespace std::chrono;

    steady_clock::time_point t1 = steady_clock::now();


    for(uint64_t i = 100000; i < n; i += 100000)
        cout << sumPrimes(i) << endl;

    steady_clock::time_point t2 = steady_clock::now();

    duration<double> time_span = duration_cast<duration<double>>(t2 - t1);
    std::cout << "It took me " << time_span.count() << " seconds." << endl;
}

BOOST_PYTHON_MODULE(prim_summer_c)
{
    bp::def("sum_primes", sum_primes);
}
