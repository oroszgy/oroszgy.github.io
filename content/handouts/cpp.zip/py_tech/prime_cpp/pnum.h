#ifndef PNUM_H_INCLUDED
#define PNUM_H_INCLUDED

#include <stdint.h>

bool isPrime(uint64_t num)
{
    if ( num < 2 )
        return false;
    if ( num < 4 )
        return true;
    for( uint64_t i = 2; /*blank*/; ++i )
    {
        if ( !( num%i ) )
            return false;
        if ( num < i*i )
            return true;
    }
}

uint64_t sumPrimes(uint64_t num)
{
    uint64_t ret(0);
    for (uint64_t i = 2; i < num; ++i)
        if (isPrime(i))
            ret += i;
    return ret;
}

#endif // PNUM_H_INCLUDED
